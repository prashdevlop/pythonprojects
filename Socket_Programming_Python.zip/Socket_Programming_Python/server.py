# server.py 
import socket                                         

#create a socket object
s = socket.socket() 

# get local machine name
host = '127.0.0.1'                           

port = 9999                                           

# bind to the port
s.bind((host, port))                                  

# queue up to 5 requests
s.listen(5)                                           

while True:
    # establish a connection
    c,addr = s.accept()     

    print("Got a connection from " + str(addr))

    z = c.recv(1024).decode('ascii')
    
    print("Received: " + z)
    z=z.upper()
    c.send(z.encode('ascii'))

c.close()
