# blockchain_server.py 
import socket                                         
import time
import blockchain_address_generator
#initial hash
a="1HoSFymoqteYrmmr7s3jDDqmggoxacbk37"

# create a socket object
s = socket.socket()

# get local machine name
host = '127.0.0.1'                           

port = 9999                                           

# bind to the port
s.bind((host, port))                                  

# queue up to 5 requests
s.listen(5)                                           

while True:
    # establish a connection
    c,addr = s.accept()     

    print("Got a connection from " + str(addr))

    z = c.recv(1024).decode('ascii')
    print("Received: " + z)
   
    if (z == a):
        msg="Mined Successfully"
        c.send(msg.encode('ascii'))
    else:
        m = "Please try another value"
        c.send(m.encode('ascii'))
c.close()
