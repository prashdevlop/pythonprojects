from bitcoin import *
x=input("Enter your Data: ")
priv_key=sha256(x)
pub_key=privtopub(priv_key)
addr=pubtoaddr(pub_key)
print("Your Hash Address is: " + addr)
