# Miner program 
import socket
from bitcoin import *
x=input("Enter value to mine data--> ")
priv_key=sha256(x)
pub_key=privtopub(priv_key)
addr=pubtoaddr(pub_key)
#def send_fun(adr):
# create a socket object
s = socket.socket()
# get local machine name
host = '127.0.0.1'
port = 9999
# connection to hostname on the port.
s.connect((host, port))                           
# Receive no more than 1024 bytes
sm = s.send(addr.encode('ascii'))
tm = s.recv(1024).decode('ascii')

print("Reply from the server: " + tm)

s.close()                         


    
                                    


